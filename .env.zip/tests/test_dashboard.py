import os
import unittest
from types import SimpleNamespace

import dashboard


class DummyAvatar:
    url = "https://cdn.example/avatar.png"

    def __bool__(self):
        return True


class DummyUser:
    id = 123456789
    display_avatar = DummyAvatar()

    def __str__(self):
        return "KoiLa#0001"


class DummyBot:
    user = DummyUser()
    guilds = [
        SimpleNamespace(
            name="Koi Pond",
            id=111,
            member_count=42,
            icon=SimpleNamespace(url="https://cdn.example/icon.png"),
        )
    ]
    cogs = {"Fun": object()}
    extensions = {"cogs.fun": object()}
    latency = 0.042
    ws = object()

    def is_ready(self):
        return True

    def is_closed(self):
        return False


class DashboardApiTests(unittest.TestCase):
    def setUp(self):
        os.environ["DASHBOARD_SECRET"] = "test-secret"
        dashboard._bot = DummyBot()
        dashboard._start_time = 1000.0
        dashboard._loop = None
        self.client = dashboard.create_app().test_client()

    def auth_headers(self):
        return {"Authorization": "Bearer test-secret"}

    def test_api_requires_bearer_token(self):
        response = self.client.get("/api/status")

        self.assertEqual(response.status_code, 401)
        self.assertIn("error", response.get_json())

    def test_status_returns_dashboard_payload(self):
        response = self.client.get("/api/status", headers=self.auth_headers())

        self.assertEqual(response.status_code, 200)
        data = response.get_json()
        self.assertEqual(data["username"], "KoiLa#0001")
        self.assertEqual(data["bot_id"], "123456789")
        self.assertEqual(data["guild_count"], 1)
        self.assertEqual(data["total_members"], 42)
        self.assertEqual(data["discord_ws"], "connected")

    def test_collection_routes_return_named_payloads(self):
        endpoints = {
            "/api/cogs": "cogs",
            "/api/guilds": "guilds",
            "/api/data-files": "files",
            "/api/logs": "logs",
        }

        for endpoint, key in endpoints.items():
            with self.subTest(endpoint=endpoint):
                response = self.client.get(endpoint, headers=self.auth_headers())
                self.assertEqual(response.status_code, 200)
                data = response.get_json()
                self.assertIsInstance(data, dict)
                self.assertIn(key, data)
                self.assertIsInstance(data[key], list)


if __name__ == "__main__":
    unittest.main()
